from html.parser import HTMLParser

class HeadingParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.headings = []
        self.current_heading_level = None
        self.inside_heading = False

    def handle_starttag(self, tag, attrs):
        if tag.lower().startswith('h') and len(tag) == 2 and tag[1].isdigit():
            self.current_heading_level = int(tag[1])
            self.inside_heading = True

    def handle_endtag(self, tag):
        if tag.lower().startswith('h') and len(tag) == 2 and tag[1].isdigit():
            self.current_heading_level = None
            self.inside_heading = False

    def handle_data(self, data):
        if self.inside_heading and self.current_heading_level is not None:
            self.headings.append((self.current_heading_level, data.strip()))

    def print_headings(self):
        for level, text in self.headings:
            print(" " * (level - 1) + text)  # Indenting based on heading level

# Testing the implementation
if __name__ == "__main__":
    with open('w3c.html', 'r', encoding='utf-8') as infile:
        content = infile.read()

    hp = HeadingParser()
    hp.feed(content)
    hp.print_headings()

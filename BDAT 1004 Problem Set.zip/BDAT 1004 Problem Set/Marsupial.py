class Marsupial:
    def __init__(self):
        self.pouch = []

    def put_in_pouch(self, item):
        self.pouch.append(item)

    def pouch_contents(self):
        return self.pouch

class Kangaroo(Marsupial):
    def __init__(self, x, y):
        super().__init__()
        self.x = x
        self.y = y

    def jump(self, dx, dy):
        self.x += dx
        self.y += dy

    def __str__(self):
        return f"I am a Kangaroo located at coordinates ({self.x},{self.y})"

# Testing the classes
if __name__ == "__main__":
    k = Kangaroo(0, 0)
    print(k)  

    k.put_in_pouch('doll')
    k.put_in_pouch('firetruck')
    k.put_in_pouch('kitten')
    print(k.pouch_contents())  

    k.jump(1, 0)
    k.jump(1, 0)
    k.jump(1, 0)
    print(k)  
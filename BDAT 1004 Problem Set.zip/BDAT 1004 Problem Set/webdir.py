import requests
from bs4 import BeautifulSoup

def webdir(url, depth, indent):
    if depth < 0:
        return
    
    # Fetching the contents of the URL
    response = requests.get(url)
    if response.status_code == 200:
        # Printing the URL with appropriate indentation
        print(" " * indent + url)
        
        # Parsing the HTML content
        soup = BeautifulSoup(response.content, 'html.parser')
        
        # Finding all links on the page
        links = soup.find_all('a', href=True)
        
        # Recursively visiting each link
        for link in links:
            href = link['href']
            if href.startswith('http'):  # Skiping the external links
                webdir(href, depth - 1, indent + 1)

# Testing the implementation
if __name__ == "__main__":
    starting_url = 'https://en.wikipedia.org/wiki/Blog'
    max_depth = 2
    starting_indent = 0
    
    webdir(starting_url, max_depth, starting_indent)
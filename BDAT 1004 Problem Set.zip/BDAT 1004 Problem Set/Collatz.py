def collatz(x):
    print(x)
    if x == 1:  # Base case - It stops when the sequence reaches to 1
        return
    elif x % 2 == 0:
        collatz(x // 2)  # Recursively calling collatz with x/2, when x is even
    else:
        collatz(3 * x + 1)  # If x is odd, then recursively calling collatz with 3x+1

# Test cases
collatz(1)
collatz(10)







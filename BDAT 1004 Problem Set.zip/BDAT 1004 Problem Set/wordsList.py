# Given list of words
words = ['The', 'quick', 'brown', 'fox', 'jumps', 'over', 'the', 'lazy', 'dog']

# a) Converting all words to uppercase
uppercase_words = [word.upper() for word in words]

# b) Keeping all words as lowercase
lowercase_words = [word.lower() for word in words]

# c) Get the lengths of all words
word_lengths = [len(word) for word in words]

# d) Create a list of lists containing the word in uppercase, lowercase, and the length of the word
word_info = [[word.upper(), word.lower(), len(word)] for word in words]

# e) Filter words containing 4 or more characters
words_with_four_or_more_characters = [word for word in words if len(word) >= 4]

# Print the results
print("a) Uppercase words:", uppercase_words)
print("b) Lowercase words:", lowercase_words)
print("c) Word lengths:", word_lengths)
print("d) Word information:", word_info)
print("e) Words with four or more characters:", words_with_four_or_more_characters)

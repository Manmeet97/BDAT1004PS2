def binary(n):
    if n > 1:
        binary(n // 2)  # Recursively calling binary with n divided by 2
    print(n % 2, end='')  # Printing the remainder of n when divided by 2 (i.e binary digit)

# Testing cases
binary(0)  
print()  # Print a newline
binary(1)  
print()  
binary(3)  
print() 
binary(9)  
